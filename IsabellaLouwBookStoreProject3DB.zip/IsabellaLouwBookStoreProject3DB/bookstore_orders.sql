-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_number` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `totalCost` decimal(10,2) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `stock` int DEFAULT '50',
  `quantity` int DEFAULT NULL,
  PRIMARY KEY (`order_number`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'The Silent Patient',770.00,'images/SilentPatient.jpg',49,2),(2,'Shatter Me',525.00,'images/ShatterMe.jpg',50,1),(3,'Shatter Me',525.00,'images/ShatterMe.jpg',49,1),(4,'Shatter Me',525.00,'images/ShatterMe.jpg',48,1),(5,'Shatter Me',525.00,'images/ShatterMe.jpg',47,1),(6,'Shatter Me',525.00,'images/ShatterMe.jpg',46,1),(7,'And Then There Were None',570.00,'images/AndThenThereWereNone.jpg',50,1),(8,'Beach Read',570.00,'images/BeachRead.jpg',50,1),(9,'One Of Us Is Lying',360.00,'images/OneOfUsIsLying.jpg',50,1),(10,'Shadow And Bone',360.00,'images/ShadowAndBone.jpg',50,1),(11,'Lightlark, Better Than The Movies',670.00,'images/Lightlark.jpg, images/BetterThanTheMovies.jpg',50,1),(12,'A Good Girl\'s Guide To Murder, Lightlark',560.00,'images/AGoodGirlsGuidetoMurder.jpg, images/Lightlark.jpg',49,1),(13,'One Of Us Is Lying',200.00,'images/OneOfUsIsLying.jpg',49,1),(14,'And Then There Were None, Lightlark',1300.00,'images/AndThenThereWereNone.jpg, images/Lightlark.jpg',48,3),(15,'The Silent Patient, Lightlark, Better Than The Movies',920.00,'images/SilentPatient.jpg, images/Lightlark.jpg, images/BetterThanTheMovies.jpg',47,1),(16,'Fourth Wing',1350.00,'images/FourthWing.jpg',47,3);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-10 18:36:03
