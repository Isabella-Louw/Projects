-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `ISBN` varchar(13) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `price` decimal(10,2) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ISBN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES ('9780062085481','Shatter Me','A girl named Juliette Ferrars who has a lethal touch. She\'s spent the past 17 years locked up because the government is afraid of her. That all changes when she\'s transferred to a new prison where she meets a boy named Adam who makes her feel human again.',220.00,'images/ShatterMe.jpg','Fantasy'),('9781250027436','Shadow And Bone','Ravka, is divided in two by a lethal expanse of darkness called the Shadow Fold. The Fold is inhabited by monsters who prey on the living, and crossing it is suicide. The story follows the journey of Alina Starkov, a mapmaker in the Ravkan army, who accidentally discovers she has the power to summon light, making her the only one who can destroy the Fold.',160.00,'images/ShadowAndBone.jpg','Fantasy'),('9781250230782','The Silent Patient','Theo Faber is a criminal psychotherapist who is determined to get Alicia to talk and unravel the mystery of why she shot her husband. His search for the truth threatens to consume him.',250.00,'images/SilentPatient.jpg','Mystery'),('9781405293181','A Good Girl\'s Guide To Murder','Five years ago, Andie Bell, a girl in Pippa\'s village, was murdered by her boyfriend Sal Singh, but the body was never found. Pippa suspects it wasn\'t an open and shut case, and chooses to make a study of it for her final year project at school.',160.00,'images/AGoodGirlsGuidetoMurder.jpg','Mystery'),('9781408261200','And Then There Were None','Ten strangers are invited to an isolated island by a mysterious host. As they start to die one by one, the remaining guests realize that the killer is among them. With no way to escape, they must uncover the murderer\'s identity before it\'s too late.',300.00,'images/AndThenThereWereNone.jpg','Mystery'),('9781419760877','Lightlark','Every 100 years, the island of Lightlark appears to host the Centennial, a deadly game that only the rulers of six realms are invited to play. The invitation is a summons—a call to embrace victory and ruin, baubles and blood. The Centennial offers the six rulers one final chance to break the curses that have plagued their realms for centuries. Each ruler has something to hide. Each realm’s curse is uniquely wicked. To destroy the curses, one ruler must die.',400.00,'images/Lightlark.jpg','Fantasy'),('9781524764722','One Of Us Is Lying','When five students are put into detention, only four come out alive. The victim is Simon - creator of the notorious school gossip app - and his death is no accident.',200.00,'images/OneOfUsIsLying.jpg','Mystery'),('9781534467620','Better Than The Movies','Liz Buxbaum is hoping to find romance with her old crush, Michael, during senior year. She\'s a huge fan of romcom films, a passion she shared with her screenwriter mom, who died several years ago. Liz imagines any potential romance in light of her favorite movies.',270.00,'images/BetterThanTheMovies.jpg','Romance'),('9781649374042','Fourth Wing','Twenty-year-old Violet Sorrengail was supposed to enter the Scribe Quadrant, living a quiet life among books and history. Now, the commanding general—also known as her tough-as-talons mother—has ordered Violet to join the hundreds of candidates striving to become the elite of Navarre: dragon riders. Friends, enemies, lovers. Everyone at Basgiath War College has an agenda—because once you enter, there are only two ways out: graduate or die.',450.00,'images/FourthWing.jpg','Fantasy'),('9781984806734','Beach Read','A romance writer who no longer believes in love and a literary writer stuck in a rut engage in a summer-long challenge that may just upend everything they believe about happily ever afters.',270.00,'images/BeachRead.jpg','Romance'),('9781984806758','People We Meet On Vacation','Poppy and Alex are best friends from college who have travelled together each summer for the last decade. But two years ago there was a rift in their friendship, and they haven\'t spoken since.  Poppy reaches out to Alex and they agree go on one more trip together.',305.00,'images/PeopleWeMeetOnVacation.jpg','Romance');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-10 18:36:04
