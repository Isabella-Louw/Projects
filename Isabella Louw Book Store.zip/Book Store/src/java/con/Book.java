package con;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.math.BigDecimal;
/**
 *Book class
 * @author Isabella Louw
 * To initialize book variables with getters and setters
 */
public class Book {
    private String title;
    private BigDecimal price;
    private String image_url;
    private int quantity;


    // Getters and setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getImageUrl() {
        return image_url;
    }

    public void setImageUrl(String image_url) {
        this.image_url = image_url;
    }
    
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
     @Override
    public String toString() {
        return "Book [title=" + title + ", price=" + price + ", imageUrl=" + image_url + ", quantity=" + quantity + "]";
    }
    
}
