package con;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */    
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * AddToCartServlet
 * @author Isabella Louw
 * This will handle when the button add to cart is clicked. The book details will be stored in Map and in a session. The total price will 
 * also be calculated.
 */
@WebServlet(urlPatterns = {"/AddToCartServlet"})
public class AddToCartServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         
        // Get the ISBN parameter from the request
        String ISBN = request.getParameter("ISBN");
        
        // Get the quantity parameter from the request and convert it from a string to a integer
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        
        // Establish database connection to retrieve book details
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookstore", "root", "Sunburst1975")) {
            String query = "SELECT title, price, image_url FROM books WHERE ISBN = ?";
            
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, ISBN);
                
                try (ResultSet rs = stmt.executeQuery()) {
                    // Retrieve existing cart from session
                    HttpSession session = request.getSession();
                    
                    //Creating a Map with a key of the ISBN and a value of a object Book
                    Map<String, Book> cart = (Map<String, Book>) session.getAttribute("cart");
                    
                    if (cart == null) {
                        cart = new HashMap<>();
                    }

                    BigDecimal totalPrice = BigDecimal.ZERO;
                    
                    while (rs.next()) {
                        Book book = new Book();
                        book.setTitle(rs.getString("title"));
                        book.setPrice(rs.getBigDecimal("price"));
                        book.setImageUrl(rs.getString("image_url"));
                        book.setQuantity(quantity);
                        cart.put(ISBN, book);
                        
                        // Update total price
                        totalPrice = totalPrice.add(book.getPrice().multiply(BigDecimal.valueOf(quantity)));
                    }
                    
                    
                    session.setAttribute("cart", cart);
                }
            }
            
            request.getRequestDispatcher("ShoppingCart.jsp").forward(request, response);
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }    
}

    


   


