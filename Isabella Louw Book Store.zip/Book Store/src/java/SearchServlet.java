/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *SearchServlet
 * @author Isabella Louw
 * This will store all the book titles in the database to an ArrayList and if a title is searched and it is in the array then the user will
 * be redirected to the relevant category page where the book is located. Otherwise the user will be redirected to a page to show that no book
 * was found.
 */
@WebServlet(urlPatterns = {"/SearchServlet"})
public class SearchServlet extends HttpServlet {
    
    //Creating ArrayList to store all book titles in database
    public ArrayList<String> bookTitles = new ArrayList<>();
    
    
    
     @Override
    public void init() throws ServletException {
        super.init();
        // Populate the array with book titles from the database
        try {
            populateBookTitles();
        } catch (SQLException | ClassNotFoundException e) {
        }
    }
    
    //Selecting all book titles from database table books
    private void populateBookTitles() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookstore?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "Sunburst1975");
             PreparedStatement ps = conn.prepareStatement("SELECT title FROM books")) {
            try (ResultSet rs = ps.executeQuery()) {
                 while (rs.next()) {
                bookTitles.add(rs.getString("title"));
                } 
            }
        }
    }
    
  
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //Getting the user inputted value in the search bar
        String searchTerm = request.getParameter("searchTerm");
        String matchedCategory = null;

        // Perform search in the array to see if what user searched mathces whats in the array
        for (String title : bookTitles) {
            if (title.toLowerCase().contains(searchTerm.toLowerCase())) {
                try {
                    matchedCategory = getCategoryForTitle(title);
                } catch (SQLException | ClassNotFoundException e) {
                    // Handle the exception appropriately
                    e.printStackTrace();
                }
                break; // Stop searching after finding the first match
            }
        }

        if (matchedCategory != null) {
            String categoryPage = getCategoryPageURL(matchedCategory);
            response.sendRedirect(request.getContextPath() + categoryPage); // Redirect to the category page if book is found
        } else {
            request.getRequestDispatcher("NoMatch.jsp").forward(request, response); // Redirect to the NoMatch page if book is not found
        }
    }

    //Searching the books table in the database to see which category the relevant book searched for belongs to
    private String getCategoryForTitle(String title) throws SQLException, ClassNotFoundException {
        String category = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookstore?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "Sunburst1975");
             PreparedStatement ps = conn.prepareStatement("SELECT category FROM books WHERE title = ?")) {
            ps.setString(1, title);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    category = rs.getString("category");
                }
            }
        }
        return category;
}

    //Using a switch-case to redirect the user to the relevant category page based on the category of the book title
    private String getCategoryPageURL(String category) {
        String categoryPageURL = null;
        switch (category) {
            case "Mystery":
                categoryPageURL = "/Mystery.jsp";
                break;
            case "Romance":
                categoryPageURL = "/Romance.jsp";
                break;
            case "Fantasy":
                categoryPageURL = "/Fantasy.jsp";
                break;
            default:
                categoryPageURL = "/NoMatch.jsp"; // Default to NoMatch.jsp if category not recognized
                break;
        }
        return categoryPageURL;
    }

       
    

}
