/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *CheckoutServlet
 * @author Isabella Louw
 * This will store the book details of the books in the cart to a table named orders in the database. The user will also be redirected to a 
 * Thank you page where their order number will be displayed.
 */
@WebServlet(urlPatterns = {"/CheckoutServlet"})
public class CheckoutServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         // Extract form parameters as arrays since more than one book can be bought at a time
        String[] titles = request.getParameterValues("titles[]");
        String[] imageUrls = request.getParameterValues("imageUrls[]");
        String[] quantities = request.getParameterValues("quantities[]");
        String totalCostStr = request.getParameter("totalCost");
        BigDecimal totalCost = new BigDecimal(totalCostStr);
        
         // Concatenate titles and image URLs
        String concatenatedTitles = String.join(", ", titles);
        String concatenatedImageUrls = String.join(", ", imageUrls);

        // Database connection to insert the book details into the table orders
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookstore", "root", "Sunburst1975")) {
            // Insert into orders table
            String insertQuery = "INSERT INTO orders (title, image_url, quantity, totalCost) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = conn.prepareStatement(insertQuery)) {
                preparedStatement.setString(1, concatenatedTitles);
                preparedStatement.setString(2, concatenatedImageUrls);
                 preparedStatement.setInt(3, Integer.parseInt(quantities[0].split(", ")[0]));
                preparedStatement.setBigDecimal(4, totalCost);
                preparedStatement.executeUpdate();




                    // Deduct stock for each book. The default stock for each book is 50
                    for (int i = 0; i < titles.length; i++) {
                        String title = titles[i];
                        int quantity = Integer.parseInt(quantities[i].split(", ")[0]);

                        String updateStockQuery = "UPDATE orders SET stock = stock - ? WHERE title = ?";
                        try (PreparedStatement ps = conn.prepareStatement(updateStockQuery)) {
                            ps.setInt(1, quantity);
                            ps.setString(2, title);
                            ps.executeUpdate();
                        }
                    }
            }

                // Clear the shopping cart after user checks out
                HttpSession session = request.getSession();
                session.removeAttribute("cart");

                // Redirect to thank you page
                response.sendRedirect("ThankYouPage.jsp"); 
            } catch (SQLException e) {
                e.printStackTrace(); // Handle database connection or query errors
                
            }
    }

}
