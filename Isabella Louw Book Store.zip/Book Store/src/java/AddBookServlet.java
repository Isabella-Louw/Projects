/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
/**
 *AddBookServlet
 * @author Isabella Louw
 * Allows connection to the database so that new books added in the form in admin.jsp can be added to the database table books
 */
@WebServlet(urlPatterns = {"/AddBookServlet"})
public class AddBookServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         // Retrieve the value of the source parameter
        String source = request.getParameter("source");
        //Retrieve parameters from form
        if ("admin".equals(source)) {
            String ISBN = request.getParameter("ISBN");
            String title = request.getParameter("title");
            String description = request.getParameter("description");
            String category = request.getParameter("category");
            BigDecimal price = new BigDecimal(request.getParameter("price"));
            String image_url = "images/" + request.getParameter("image_url");
            
            //Adding the details to the database table books
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookstore","root","Sunburst1975")) {
                String sql = "INSERT INTO books (ISBN, title, category, description, price, image_url) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement statement = conn.prepareStatement(sql)) {
                    statement.setString(1, ISBN);
                    statement.setString(2, title);
                    statement.setString(3, category);
                    statement.setString(4, description);
                    statement.setBigDecimal(5, price);
                    statement.setString(6, image_url);

                    int i = statement.executeUpdate();
                    if (i > 0) {
                        // Set attributes to display inserted book details
                        request.setAttribute("title", title);
                        request.setAttribute("category", category);
                        request.setAttribute("description", description);
                        request.setAttribute("price", price);
                        request.setAttribute("image_url", image_url);

                        // Forward the request to admin.jsp to display the details
                        request.getRequestDispatcher("admin.jsp").forward(request, response);
                        return; // Exit the servlet method after forwarding
                    } else {
                        // Handle an error appropriately
                        PrintWriter pw = response.getWriter();
                        pw.println("Some Error Occurred, try again later");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                // Redirect back to admin.jsp on error
                response.sendRedirect("admin.jsp");
            }
        } else {
            // Redirect to admin.jsp
            response.sendRedirect("admin.jsp");  
        }
    }


}
