﻿/*
 * Author: Isabella Louw
 * Date: 10 April 2024
 * Subject: Basic C#
 * Project : 1
 * Description: This program implements a Hangman game using Windows Forms. The words are picked at random and 
 * displayed by underscores. The user has to type letters that they think are correct and if they are the 
 * underscores will be replaced by the correct letter. However, if the letter is wrong the letters will be 
 * displayed underneath the word that you should guess. The user gets 10 incorrect guesses before they loose 
 * the game. If they loose a message will be displayed to display what the word was. If they guessed correctly 
 * a message box will display that they won and the word and number of guesses it took them will be displayed
 * in the scoreboard. To end the game or start a new game the user can click the buttons on either side of the form.
 */


using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hangman_Game
{
    public partial class Form1 : Form
    {
        // Declaration of class variables
        private string[] words = { "bookworm", "computer", "programming", "jazz", "developer", "butterfly",
        "dolphin", "bookcase", "cookbook", "zipper", "kayak", "pajama", "sunglasses", "swimming", "golf","piano"};
        private string currentWord;
        private ArrayList correctGuesses = new ArrayList();
        private ArrayList incorrectGuesses = new ArrayList();
        private SortedList<string, int> scoreboard = new SortedList<string, int>();
        private int wrongGuesses = 0;
        public Form1()
        {
            InitializeComponent();
            // Call the method to start a new game when the form is initialized
            StartNewGame();
        }

        private void StartNewGame()
        {
            // Reset game variables
            wrongGuesses = 0;
            correctGuesses.Clear();
            incorrectGuesses.Clear();
            // Get a new random word
            currentWord = GetRandomWord();
            UpdateWordDisplay();
            

            // Update UI elements
            UpdateGuessesDisplay();
            UpdateScoreboardDisplay();
        }

        private string GetRandomWord()
        {
            try {
                Random random = new Random();
                // Get a random word from the 'words' array
                return words[random.Next(words.Length)];
            } 
            catch (Exception ex) {
                MessageBox.Show("An error occurred while generating a random word: " + ex.Message);
                // Return empty string as a fallback
                return ""; 
            }
            
        }

        private void UpdateWordDisplay()
        {
            // Clear the word label
            lblWord.Text = "";
            foreach (char letter in currentWord)
            {
                if (correctGuesses.Contains(letter))
                    // Display correct guessed letters
                    lblWord.Text += letter + " ";
                else
                    // Display placeholder for letters not guessed yet
                    lblWord.Text += "_ ";
            }
        }

        private void UpdateGuessesDisplay()
        {
            // Display incorrect guessed letters
            lblIncorrectQuess.Text = string.Join(" ", incorrectGuesses.Cast<char>());
        }

        private void UpdateScoreboardDisplay()
        {
            // Clear the scoreboard list box
            lstScoreboard.Items.Clear();
            foreach (KeyValuePair<string, int> score in scoreboard)
            {
                // Add each score to the scoreboard list box
                lstScoreboard.Items.Add(score.Key + ": " + score.Value + " guesses");
            }
        }
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Handle key presses
            if (char.IsLetter(e.KeyChar))
            {
                char guessedLetter = char.ToLower(e.KeyChar);
                if (currentWord.Contains(guessedLetter))
                {
                    if (!correctGuesses.Contains(guessedLetter))
                    {
                        // Add correct guessed letter
                        correctGuesses.Add(guessedLetter);
                        // Update displayed word
                        UpdateWordDisplay();
                        if (currentWord.All(c => correctGuesses.Contains(c)))
                        {
                            // Player wins
                            MessageBox.Show("Congratulations! You won!");
                            int totalGuesses = correctGuesses.Count + incorrectGuesses.Count;
                            if (!scoreboard.ContainsKey(currentWord) || scoreboard[currentWord] > totalGuesses)
                                // Update scoreboard with total guesses
                                scoreboard[currentWord] = totalGuesses;
                            StartNewGame();
                        }
                    }
                }
                else
                {
                    if (!incorrectGuesses.Contains(guessedLetter))
                    {
                        // Add incorrect guessed letter
                        incorrectGuesses.Add(guessedLetter);
                        wrongGuesses++;
                        // Update displayed incorrect guesses
                        UpdateGuessesDisplay();
                        if (wrongGuesses >= 10)
                        {
                            // Player loses
                            MessageBox.Show("Game Over! The word was: " + currentWord);
                            //Start a new game
                            StartNewGame();
                        }
                    }
                }
            }

        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            // Clear the scoreboard
            scoreboard.Clear();
            // Start a new game
            StartNewGame();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
