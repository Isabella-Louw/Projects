﻿namespace Hangman_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNewGame = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.lstScoreboard = new System.Windows.Forms.ListBox();
            this.lblWord = new System.Windows.Forms.Label();
            this.lblIncorrectQuess = new System.Windows.Forms.Label();
            this.lblScoreHeading = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnNewGame
            // 
            this.btnNewGame.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnNewGame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnNewGame.Font = new System.Drawing.Font("Modern No. 20", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewGame.Location = new System.Drawing.Point(52, 406);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(148, 84);
            this.btnNewGame.TabIndex = 0;
            this.btnNewGame.Text = "New Game";
            this.btnNewGame.UseVisualStyleBackColor = false;
            this.btnNewGame.Click += new System.EventHandler(this.btnNewGame_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnQuit.BackColor = System.Drawing.Color.Red;
            this.btnQuit.Font = new System.Drawing.Font("Modern No. 20", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuit.Location = new System.Drawing.Point(1099, 406);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(146, 86);
            this.btnQuit.TabIndex = 1;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // lstScoreboard
            // 
            this.lstScoreboard.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lstScoreboard.FormattingEnabled = true;
            this.lstScoreboard.HorizontalScrollbar = true;
            this.lstScoreboard.ItemHeight = 20;
            this.lstScoreboard.Location = new System.Drawing.Point(1042, 86);
            this.lstScoreboard.Name = "lstScoreboard";
            this.lstScoreboard.ScrollAlwaysVisible = true;
            this.lstScoreboard.Size = new System.Drawing.Size(208, 264);
            this.lstScoreboard.TabIndex = 2;
            // 
            // lblWord
            // 
            this.lblWord.AutoSize = true;
            this.lblWord.BackColor = System.Drawing.Color.Transparent;
            this.lblWord.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWord.ForeColor = System.Drawing.Color.White;
            this.lblWord.Location = new System.Drawing.Point(508, 86);
            this.lblWord.Name = "lblWord";
            this.lblWord.Size = new System.Drawing.Size(0, 41);
            this.lblWord.TabIndex = 3;
            // 
            // lblIncorrectQuess
            // 
            this.lblIncorrectQuess.AutoSize = true;
            this.lblIncorrectQuess.BackColor = System.Drawing.Color.Transparent;
            this.lblIncorrectQuess.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIncorrectQuess.ForeColor = System.Drawing.Color.White;
            this.lblIncorrectQuess.Location = new System.Drawing.Point(508, 269);
            this.lblIncorrectQuess.Name = "lblIncorrectQuess";
            this.lblIncorrectQuess.Size = new System.Drawing.Size(0, 41);
            this.lblIncorrectQuess.TabIndex = 4;
            // 
            // lblScoreHeading
            // 
            this.lblScoreHeading.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblScoreHeading.AutoSize = true;
            this.lblScoreHeading.BackColor = System.Drawing.Color.Yellow;
            this.lblScoreHeading.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScoreHeading.Location = new System.Drawing.Point(1055, 32);
            this.lblScoreHeading.Name = "lblScoreHeading";
            this.lblScoreHeading.Size = new System.Drawing.Size(168, 34);
            this.lblScoreHeading.TabIndex = 5;
            this.lblScoreHeading.Text = "Scoreboard";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(1273, 529);
            this.Controls.Add(this.lblScoreHeading);
            this.Controls.Add(this.lblIncorrectQuess);
            this.Controls.Add(this.lblWord);
            this.Controls.Add(this.lstScoreboard);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnNewGame);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "HangmanForm";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.ListBox lstScoreboard;
        private System.Windows.Forms.Label lblWord;
        private System.Windows.Forms.Label lblIncorrectQuess;
        private System.Windows.Forms.Label lblScoreHeading;
    }
}

